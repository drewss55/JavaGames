TO RUN PONG:
1. Open "page.html" in Internet Explorer
2. You might have to alter your security settings in the Java Control Panel